<div align = center>
<h1>ML_Lab_3</h1>
</div>

## 1. Công nghệ sử dụng:

 - Framework: pandas, sckit-learn, Flask, pickle

## 2. Thuật toán:

 - Centroid KNN (K Nearest Neighbors)

## 3. Hiển thị kết quả lên website:

![Ketquaweb](web.jpg)

## 4. Kết quả của 3 bài tập lab 3:

 - Centroid:

![Centroid](centroid.png)

 - Bài tâp 1:

![Cau1](cau1.png)

 - Bài tập 2:

![Cau2](cau2.png)
