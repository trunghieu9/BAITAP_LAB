<div align = center>
<h1>ML_Lab_4</h1>
</div>

## 1. Công nghệ sử dụng:

 - Framework: pandas, sckit-learn, numpy

## 2. Thuật toán:

 - Random Forest, Decision Tree
